/// <reference types="react" />
export default function Footer(): import("react").JSX.Element;
