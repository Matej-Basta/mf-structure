export default class SafeComponent extends React.Component<any, any, any> {
    static getDerivedStateFromError(error: any): {
        hasError: boolean;
    };
    constructor(props: any);
    state: {
        hasError: boolean;
    };
    componentDidCatch(): void;
    render(): any;
}
import React from "react";
